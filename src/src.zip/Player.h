#pragma once
#include "Game.h"

class Player : public sf::RectangleShape {
    public:
    Player(float x, float y);
    ~Player();

    void update(float delta, sf::RenderWindow& window);

    private:
    float size = 50;
    float speed = 150;
};
