#pragma once
#include "Game.h"
#include "Player.h"

class Enemy: public sf::RectangleShape{
    public:
    Enemy(float x, float y);
    ~Enemy();

    void update(float delta, Player& player);

    private:
    float size = 75;
    float speed = 200;

    bool checkCollision(const Player& player) const;
};
