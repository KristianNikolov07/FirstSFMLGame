#include "Game.h"

Player player(350, 600);
Enemy enemy(200, -10);

Game::Game() {
    window.create(sf::VideoMode({800, 800}), "SFML Game", sf::Style::Titlebar | sf::Style::Close);
    window.setFramerateLimit(60);

}

Game::~Game() {

}

void Game::HandleEvents() {
    while (auto event = window.pollEvent()) {
        if (event->is<sf::Event::Closed>()) {
            window.close();
        }
    }
}

void Game::Update() {
    float delta = clock.restart().asSeconds();

    player.update(delta, window);
    enemy.update(delta, player);
}

void Game::Render() {
    window.clear(sf::Color::Black);

    window.draw(player);
    window.draw(enemy);

    window.display();
}


